const BlackScreen = () => (
  <div className="fixed inset-0 bg-black z-50" />
);

export default BlackScreen;
