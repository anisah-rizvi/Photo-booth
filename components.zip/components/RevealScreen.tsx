import { useRef, useState } from "react";
import html2canvas from "html2canvas";

interface RevealScreenProps {
  photos: string[];
  userName?: string;
  onRestart: () => void;
}

const KewpieCupid = () => (
  <svg viewBox="0 0 80 100" className="w-16 md:w-20" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Head */}
    <circle cx="40" cy="22" r="18" fill="hsl(20 80% 85%)" stroke="hsl(263 70% 50%)" strokeWidth="1.5"/>
    {/* Hair curl */}
    <path d="M30 10 Q40 0 50 10" stroke="hsl(263 70% 50%)" strokeWidth="2" fill="none"/>
    {/* Eyes */}
    <circle cx="34" cy="20" r="2" fill="hsl(263 70% 50%)"/>
    <circle cx="46" cy="20" r="2" fill="hsl(263 70% 50%)"/>
    {/* Smile */}
    <path d="M35 28 Q40 33 45 28" stroke="hsl(263 70% 50%)" strokeWidth="1.5" fill="none"/>
    {/* Body */}
    <ellipse cx="40" cy="55" rx="14" ry="20" fill="hsl(20 80% 85%)" stroke="hsl(263 70% 50%)" strokeWidth="1.5"/>
    {/* Wings */}
    <path d="M26 45 Q10 35 18 50 Q10 55 26 55" fill="hsl(330 70% 85%)" stroke="hsl(263 70% 50%)" strokeWidth="1"/>
    <path d="M54 45 Q70 35 62 50 Q70 55 54 55" fill="hsl(330 70% 85%)" stroke="hsl(263 70% 50%)" strokeWidth="1"/>
    {/* Legs */}
    <line x1="34" y1="75" x2="32" y2="95" stroke="hsl(263 70% 50%)" strokeWidth="2"/>
    <line x1="46" y1="75" x2="48" y2="95" stroke="hsl(263 70% 50%)" strokeWidth="2"/>
    {/* Bow */}
    <path d="M20 60 Q15 55 10 58 L30 70" stroke="hsl(330 70% 60%)" strokeWidth="1.5" fill="none"/>
    <line x1="10" y1="58" x2="5" y2="50" stroke="hsl(330 70% 60%)" strokeWidth="1.5"/>
  </svg>
);

const RevealScreen = ({ photos, userName = "gena", onRestart }: RevealScreenProps) => {
  const stripRef = useRef<HTMLDivElement>(null);
  const [showNote, setShowNote] = useState(false);
  const [effect, setEffect] = useState<"normal" | "bw" | "sepia">("normal");
  const [senderName, setSenderName] = useState("Marisa");
  const [noteContent, setNoteContent] = useState("I wish you peace, happiness, and less back pain");

  const cleanUserName = userName.replace(/[,.!?]+$/, '').trim() || "Gena";

  const getEffectClass = () => {
    switch (effect) {
      case "bw": return "grayscale";
      case "sepia": return "sepia";
      default: return "";
    }
  };

  const handleDownload = async () => {
    if (!stripRef.current) return;
    try {
      const canvas = await html2canvas(stripRef.current, {
        backgroundColor: null,
        scale: 2,
        useCORS: true,
      });
      const link = document.createElement("a");
      link.download = "photobooth-strip.png";
      link.href = canvas.toDataURL("image/png");
      link.click();
    } catch (err) {
      console.error("Download error:", err);
    }
  };

  return (
    <div className="fixed inset-0 bg-background flex items-center justify-center overflow-auto p-4">
      <div className="flex flex-col md:flex-row items-center gap-8 max-w-4xl">
        {/* Photo strip */}
        <div ref={stripRef} className="relative">
          <div className="bg-[hsl(40,30%,95%)] p-4 pb-8 shadow-2xl transform rotate-[-6deg] hover:rotate-0 transition-transform duration-500">
            <div className="flex flex-col gap-2">
              {photos.map((photo, i) => (
                <div key={i} className="w-48 md:w-56 aspect-[4/3] overflow-hidden bg-black">
                  <img
                    src={photo}
                    alt={`Photo ${i + 1}`}
                    className={`w-full h-full object-cover scale-x-[-1] ${getEffectClass()}`}
                    crossOrigin="anonymous"
                  />
                </div>
              ))}
            </div>
            <p className="font-script text-center text-primary mt-3 text-lg flex justify-center items-baseline gap-1">
              <input
                type="text"
                value={senderName}
                onChange={(e) => setSenderName(e.target.value)}
                className="bg-transparent border-b border-transparent hover:border-primary/20 focus:border-primary/50 outline-none text-right capitalize w-20 transition-colors"
                spellCheck="false"
              /> 
              <span className="capitalize">& {cleanUserName}</span>
            </p>
            <p className="font-display italic text-center text-primary/60 text-xs mt-1">
              Valentine's 2026
            </p>
          </div>

          {/* Cupid overlay */}
          <div className="absolute -top-6 -right-8 transform rotate-12">
            <KewpieCupid />
          </div>
        </div>

        {/* Right side — note card + actions */}
        <div className="flex flex-col items-center gap-6">
          {!showNote ? (
            <button
              onClick={() => setShowNote(true)}
              className="font-display italic text-lg text-primary underline underline-offset-4 hover:text-primary/80 transition-colors"
            >
              read your note ♡
            </button>
          ) : (
            <div className="bg-[hsl(40,30%,95%)] p-6 md:p-8 shadow-xl w-64 md:w-80 transform rotate-[3deg] animate-scale-in">
              <p className="font-script text-xl md:text-2xl text-primary leading-relaxed capitalize">
                {cleanUserName},
              </p>
              <textarea
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                className="font-script text-lg md:text-xl text-primary/80 mt-3 leading-relaxed bg-transparent border-b border-dashed border-transparent hover:border-primary/20 focus:border-primary/50 outline-none resize-none w-full h-24 focus:bg-white/40 rounded transition-all p-1"
                spellCheck="false"
              />
              <div className="flex justify-end items-center mt-4 text-primary">
                <span className="font-script text-lg md:text-xl mr-2">—</span>
                <input
                  type="text"
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  className="font-script text-lg md:text-xl bg-transparent border-b border-dashed border-transparent hover:border-primary/20 focus:border-primary/50 focus:bg-white/40 outline-none text-center w-28 rounded transition-all capitalize px-1"
                  spellCheck="false"
                />
              </div>
            </div>
          )}

          <div className="flex flex-col items-center gap-4 mt-4">
            <div className="flex gap-2">
              <button
                 onClick={() => setEffect("normal")}
                 className={`font-display px-4 py-1.5 rounded-full border-2 border-primary text-sm transition-colors ${effect === "normal" ? "bg-primary text-primary-foreground" : "text-primary hover:bg-primary/10"}`}
              >Normal</button>
              <button
                 onClick={() => setEffect("bw")}
                 className={`font-display px-4 py-1.5 rounded-full border-2 border-primary text-sm transition-colors ${effect === "bw" ? "bg-primary text-primary-foreground" : "text-primary hover:bg-primary/10"}`}
              >B&W</button>
              <button
                 onClick={() => setEffect("sepia")}
                 className={`font-display px-4 py-1.5 rounded-full border-2 border-primary text-sm transition-colors ${effect === "sepia" ? "bg-primary text-primary-foreground" : "text-primary hover:bg-primary/10"}`}
              >Vintage</button>
            </div>
            <div className="flex gap-4">
              <button
                onClick={handleDownload}
                className="bg-primary text-primary-foreground font-display px-6 py-2.5 rounded-full hover:bg-primary/90 transition-all hover:scale-105 active:scale-95 shadow-lg text-sm"
              >
                download ↓
              </button>
              <button
                onClick={onRestart}
                className="border-2 border-primary text-primary font-display px-6 py-2.5 rounded-full hover:bg-primary/10 transition-all hover:scale-105 active:scale-95 text-sm"
              >
                retake
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RevealScreen;
