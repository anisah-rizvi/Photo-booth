import { useEffect } from "react";

interface PrintingScreenProps {
  onDone: () => void;
}

const PrintingScreen = ({ onDone }: PrintingScreenProps) => {
  useEffect(() => {
    const timer = setTimeout(onDone, 3500);
    return () => clearTimeout(timer);
  }, [onDone]);

  return (
    <div className="fixed inset-0 bg-primary flex flex-col items-center justify-center overflow-hidden">
      <p className="font-display italic text-3xl md:text-5xl text-primary-foreground mb-12">
        photo is printing...
      </p>

      {/* Polaroid frame animating down */}
      <div className="animate-print-slide">
        <div className="bg-white p-3 pb-12 shadow-2xl w-48 md:w-64">
          <div className="w-full aspect-[3/4] bg-muted/30 flex items-center justify-center">
            <div className="w-8 h-8 border-4 border-primary-foreground/40 border-t-primary-foreground rounded-full animate-spin" />
          </div>
        </div>
      </div>

      {/* Checkered pattern at bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-16 checkered-pattern opacity-30" />
    </div>
  );
};

export default PrintingScreen;
