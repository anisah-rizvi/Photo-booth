import { useEffect, useRef, useState, useCallback } from "react";

interface CaptureScreenProps {
  photoIndex: number; // 0, 1, 2
  onCapture: (dataUrl: string) => void;
}

const CaptureScreen = ({ photoIndex, onCapture }: CaptureScreenProps) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [countdown, setCountdown] = useState(3);
  const [showFlash, setShowFlash] = useState(false);
  const [phase, setPhase] = useState<"countdown" | "capture">("countdown");

  const capturePhoto = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.9);
    setShowFlash(true);
    setTimeout(() => {
      setShowFlash(false);
      // Stop stream after last photo
      if (photoIndex === 2) {
        streamRef.current?.getTracks().forEach(t => t.stop());
      }
      onCapture(dataUrl);
    }, 500);
  }, [onCapture, photoIndex]);

  useEffect(() => {
    const startCamera = async () => {
      try {
        let stream;
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 } }
          });
        } catch (e) {
          console.warn("Falling back to default camera request:", e);
          // Fallback if facingMode constraint is not supported
          stream = await navigator.mediaDevices.getUserMedia({
            video: true
          });
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(e => console.error("Play error:", e));
        }
      } catch (err) {
        console.error("Camera error:", err);
      }
    };
    startCamera();

    return () => {
      // Only stop if unmounting completely (not between captures)
      if (photoIndex === 2) {
        streamRef.current?.getTracks().forEach(t => t.stop());
      }
    };
  }, []);

  useEffect(() => {
    if (phase !== "countdown") return;
    if (countdown <= 0) {
      setPhase("capture");
      capturePhoto();
      return;
    }
    const timer = setTimeout(() => setCountdown(c => c - 1), 1000);
    return () => clearTimeout(timer);
  }, [countdown, phase, capturePhoto]);

  return (
    <div className="fixed inset-0 bg-muted flex flex-col items-center justify-center">
      {/* Webcam feed */}
      <div className="relative w-full max-w-2xl aspect-[4/3] bg-black rounded-lg overflow-hidden shadow-2xl">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-full h-full object-cover scale-x-[-1]"
        />

        {/* Countdown overlay */}
        {phase === "countdown" && countdown > 0 && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/30">
            <span className="font-display italic text-[120px] md:text-[180px] text-white/90 drop-shadow-lg">
              {countdown}
            </span>
          </div>
        )}

        {/* Flash effect */}
        {showFlash && (
          <div className="absolute inset-0 bg-white animate-flash" />
        )}
      </div>

      {/* Photo counter */}
      <div className="mt-6 flex gap-3">
        {[0, 1, 2].map(i => (
          <div
            key={i}
            className={`w-4 h-4 rounded-full border-2 border-primary transition-all ${
              i <= photoIndex ? "bg-primary" : "bg-transparent"
            }`}
          />
        ))}
      </div>
      <p className="mt-2 font-display italic text-lg text-muted-foreground">
        photo {photoIndex + 1} of 3
      </p>
    </div>
  );
};

export default CaptureScreen;
