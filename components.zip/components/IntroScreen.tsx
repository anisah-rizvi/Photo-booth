import { useState } from "react";

interface IntroScreenProps {
  onStart: (name: string) => void;
}

const CurtainSVG = () => (
  <svg viewBox="0 0 200 400" className="w-48 md:w-64 h-auto" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Curtain drapes */}
    <path d="M0 0 Q30 50 20 150 Q10 250 30 400 L0 400Z" fill="hsl(263 70% 50% / 0.3)" stroke="hsl(263 70% 50%)" strokeWidth="2"/>
    <path d="M0 0 Q60 80 40 200 Q20 320 50 400 L0 400Z" fill="hsl(263 70% 50% / 0.2)" stroke="hsl(263 70% 50%)" strokeWidth="1.5"/>
    <path d="M200 0 Q170 50 180 150 Q190 250 170 400 L200 400Z" fill="hsl(263 70% 50% / 0.3)" stroke="hsl(263 70% 50%)" strokeWidth="2"/>
    <path d="M200 0 Q140 80 160 200 Q180 320 150 400 L200 400Z" fill="hsl(263 70% 50% / 0.2)" stroke="hsl(263 70% 50%)" strokeWidth="1.5"/>
    {/* Curtain rod */}
    <line x1="0" y1="5" x2="200" y2="5" stroke="hsl(263 70% 50%)" strokeWidth="4" strokeLinecap="round"/>
    {/* Tassels */}
    <circle cx="30" cy="15" r="5" fill="hsl(263 70% 50% / 0.5)"/>
    <circle cx="170" cy="15" r="5" fill="hsl(263 70% 50% / 0.5)"/>
  </svg>
);

const BootSVG = () => (
  <div className="animate-swing inline-block">
    <svg viewBox="0 0 80 120" className="w-16 md:w-24 h-auto" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* String */}
      <line x1="40" y1="0" x2="40" y2="30" stroke="hsl(263 70% 50%)" strokeWidth="2"/>
      {/* Boot body */}
      <path d="M25 30 L25 80 L15 85 L10 95 L10 105 L70 105 L70 95 L55 85 L55 30 Z"
        fill="hsl(263 70% 50% / 0.2)" stroke="hsl(263 70% 50%)" strokeWidth="2.5" strokeLinejoin="round"/>
      {/* Boot heel */}
      <rect x="10" y="105" width="60" height="10" rx="3" fill="hsl(263 70% 50% / 0.3)" stroke="hsl(263 70% 50%)" strokeWidth="2"/>
      {/* Boot top cuff */}
      <path d="M23 30 Q40 38 57 30" stroke="hsl(263 70% 50%)" strokeWidth="2" fill="none"/>
      {/* Laces */}
      <line x1="35" y1="45" x2="45" y2="45" stroke="hsl(263 70% 50%)" strokeWidth="1.5"/>
      <line x1="35" y1="55" x2="45" y2="55" stroke="hsl(263 70% 50%)" strokeWidth="1.5"/>
      <line x1="35" y1="65" x2="45" y2="65" stroke="hsl(263 70% 50%)" strokeWidth="1.5"/>
    </svg>
  </div>
);

const IntroScreen = ({ onStart }: IntroScreenProps) => {
  const [name, setName] = useState("gena,");

  return (
    <div className="fixed inset-0 bg-background flex flex-col items-center justify-center overflow-hidden">
      {/* Main content */}
      <div className="flex flex-col items-center text-center z-10 relative">
        <input 
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="your name..."
          className="font-script text-2xl md:text-3xl text-primary/70 mb-2 bg-transparent text-center border-b-[1px] border-transparent hover:border-primary/30 focus:border-primary/50 outline-none transition-colors w-64"
        />
        <h1 className="font-display italic text-4xl md:text-6xl lg:text-7xl text-primary font-bold mb-8 leading-tight">
          be my<br />valentine's?
        </h1>
        <button
          onClick={() => onStart(name)}
          className="bg-primary text-primary-foreground font-display text-lg md:text-xl px-10 py-3 rounded-full hover:bg-primary/90 transition-all hover:scale-105 active:scale-95 shadow-lg"
        >
          start
        </button>
      </div>

      {/* Curtain — right side */}
      <div className="absolute right-0 top-0 opacity-60">
        <CurtainSVG />
      </div>

      {/* Swinging boot — bottom right */}
      <div className="absolute bottom-20 right-12 md:right-24">
        <BootSVG />
      </div>

      {/* Checkered pattern at bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-16 checkered-pattern" />
    </div>
  );
};

export default IntroScreen;
