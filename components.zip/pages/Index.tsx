import { useState, useCallback } from "react";
import IntroScreen from "@/components/IntroScreen";
import BlackScreen from "@/components/BlackScreen";
import CaptureScreen from "@/components/CaptureScreen";
import PrintingScreen from "@/components/PrintingScreen";
import RevealScreen from "@/components/RevealScreen";

type AppState = "intro" | "black" | "capture" | "printing" | "reveal";

const Index = () => {
  const [state, setState] = useState<AppState>("intro");
  const [photos, setPhotos] = useState<string[]>([]);
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [userName, setUserName] = useState("Gena");

  const handleStart = useCallback((name: string) => {
    if (name) setUserName(name);
    setState("black");
    setTimeout(() => {
      setState("capture");
    }, 1200);
  }, []);

  const handleCapture = useCallback((dataUrl: string) => {
    setPhotos(prev => {
      const updated = [...prev, dataUrl];
      if (updated.length >= 3) {
        // All 3 photos taken
        setTimeout(() => setState("printing"), 300);
      } else {
        // Show black screen briefly between captures
        setState("black");
        setTimeout(() => {
          setCurrentPhotoIndex(updated.length);
          setState("capture");
        }, 800);
      }
      return updated;
    });
  }, []);

  const handlePrintingDone = useCallback(() => {
    setState("reveal");
  }, []);

  const handleRestart = useCallback(() => {
    setPhotos([]);
    setCurrentPhotoIndex(0);
    setState("intro");
  }, []);

  return (
    <>
      {state === "intro" && <IntroScreen onStart={handleStart} />}
      {state === "black" && <BlackScreen />}
      {state === "capture" && (
        <CaptureScreen
          key={currentPhotoIndex}
          photoIndex={currentPhotoIndex}
          onCapture={handleCapture}
        />
      )}
      {state === "printing" && <PrintingScreen onDone={handlePrintingDone} />}
      {state === "reveal" && <RevealScreen photos={photos} userName={userName} onRestart={handleRestart} />}
    </>
  );
};

export default Index;
